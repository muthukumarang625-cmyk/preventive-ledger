# PM Ledger – Preventive Maintenance Tracker

A simple, no-install ledger for fixtures and equipment: store each asset, its maintenance interval,
last maintenance date, and the automatically calculated next due date (Overdue / Due soon / OK).

## Features
- Add / edit / delete assets (Equipment or Fixture) with ID, location, interval (days), notes
- "Log done" records a maintenance entry (date, by, remarks) and updates last + next due date
- Per-asset history, search, filters, dashboard counts
- Export CSV, backup/restore JSON
- Data is stored in your browser (localStorage) – back up regularly

## Run
Open `index.html` in a browser. No build step.

## Put it on GitHub
```bash
git init && git add . && git commit -m "PM Ledger v1"
git branch -M main
git remote add origin https://github.com/<you>/pm-ledger.git
git push -u origin main
```
Then in the repo: Settings → Pages → Source: **GitHub Actions**. The included workflow publishes the app.

## Next ideas
Shared database (Firebase/Supabase) for multi-user use, photo upload, email/WhatsApp reminders, QR code per asset, checklists.
